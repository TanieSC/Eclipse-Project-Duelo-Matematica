package view;

import javafx.animation.FadeTransition;
import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.ParallelTransition;
import javafx.animation.Timeline;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MainMenuView {

    private final Stage stage;
    private final StackPane root;
    private final VBox menuContent;
    
    private final Button loginButton;
    private final Button registerButton;
    private final Button exitButton;

    public MainMenuView(Stage stage) {
        this.stage = stage;

        Node headerLabel = ViewUtils.createMainTitleLabel("Duelo\nX\nMatematica");
        loginButton    = ViewUtils.createSpriteButton("/buttons/btn.png", "LOGIN", null);
        registerButton = ViewUtils.createSpriteButton("/buttons/btn.png", "CREATE ACCOUNT", null);
        exitButton     = ViewUtils.createSpriteButton("/buttons/btn.png", "EXIT", null);

        VBox buttonBox = new VBox(15, loginButton, registerButton, exitButton);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setFillWidth(true);

        menuContent = new VBox(30, headerLabel, buttonBox);
        menuContent.setAlignment(Pos.CENTER);
        menuContent.setFillWidth(false);
        menuContent.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);

        root = new StackPane(menuContent);
        root.setStyle("-fx-background-color: #ffffff;");

        stage.setTitle("Duelo X Matematica");
        stage.setScene(new Scene(root, 800, 500)); 
    }

    /**
     * FULL SCREEN SWAP (e.g., going to Game Menu, Topic Selection)
     * This replaces everything.
     */
    public void setContent(Node newNode) {
        root.getChildren().setAll(newNode);
    }

    /**
     * OVERLAY SWAP (Popups like Settings, Profile, Leaderboard)
     * This drops the view down ON TOP of whatever is currently showing.
     */

    /**
     * OVERLAY SWAP — Drops down a new popup. 
     * If a popup is ALREADY open, it rolls the old one up first!
     */
    public void setOverlayContent(Node newNode) {
        // =========================================================
        // 1. CHECK IF A POPUP IS ALREADY OPEN (size >= 3 means parent + overlay + popup)
        // =========================================================
        if (root.getChildren().size() >= 3) {
            Node oldTopNode = root.getChildren().get(root.getChildren().size() - 1);
            
            if (oldTopNode instanceof StackPane) {
                StackPane oldContainer = (StackPane) oldTopNode;
                Rectangle clip = (Rectangle) oldContainer.getClip();
                
                if (clip != null) {
                    // Animate the old popup rolling up
                    Timeline clipTimeline = new Timeline(
                        new KeyFrame(Duration.ZERO, new KeyValue(clip.heightProperty(), clip.getHeight())),
                        new KeyFrame(Duration.millis(250), new KeyValue(clip.heightProperty(), 0, Interpolator.EASE_IN))
                    );

                    // Animate the old wood in reverse
                    Timeline woodTimeline = null;
                    Node graphicNode = oldContainer.getChildren().get(0);
                    if (graphicNode instanceof ImageView) {
                        ImageView woodBackground = (ImageView) graphicNode;
                        Image woodImg = woodBackground.getImage();
                        double frameWidth = woodImg.getWidth() / 12.0;
                        double frameHeight = woodImg.getHeight();

                        woodTimeline = new Timeline();
                        for (int i = 0; i < 12; i++) {
                            final int frame = 11 - i;
                            woodTimeline.getKeyFrames().add(new KeyFrame(Duration.millis(i * 20), e -> {
                                woodBackground.setViewport(new Rectangle2D(frame * frameWidth, 0, frameWidth, frameHeight));
                            }));
                        }
                    }

                    ParallelTransition transition = new ParallelTransition(clipTimeline);
                    if (woodTimeline != null) transition.getChildren().add(woodTimeline);

                    transition.setOnFinished(e -> {
                        // Remove the old popup
                        root.getChildren().remove(oldContainer);
                        // Call this method AGAIN with the new view to drop it down
                        setOverlayContent(newNode); 
                    });
                    
                    transition.play();
                    return; // Stop here. Wait for the roll-up to finish before dropping down.
                }
            }
        }

        // =========================================================
        // 2. DROP DOWN THE NEW POPUP
        // =========================================================
        Region darkOverlay;
        
        // If the dark overlay is already there (index 1), reuse it!
        if (root.getChildren().size() >= 2) {
            darkOverlay = (Region) root.getChildren().get(1);
        } else {
            // We are opening the VERY FIRST popup. Create and fade in the dark overlay.
            darkOverlay = new Region();
            darkOverlay.setStyle("-fx-background-color: rgba(0, 0, 0, 0.5);");
            darkOverlay.setOpacity(0);
            
            FadeTransition fadeOverlay = new FadeTransition(Duration.millis(200), darkOverlay);
            fadeOverlay.setToValue(1.0);
            fadeOverlay.play();
            
            root.getChildren().add(darkOverlay);
        }

        // Setup the wooden background
        Image woodImg = new Image(getClass().getResourceAsStream("/_assets/panels/ui_popup_scroll.png"));
        ImageView woodBackground = new ImageView(woodImg);
        Region viewRegion = (Region) newNode;
        
        woodBackground.setPreserveRatio(false);
        woodBackground.fitWidthProperty().bind(viewRegion.widthProperty());
        woodBackground.fitHeightProperty().bind(viewRegion.heightProperty());

        StackPane dropdownContainer = new StackPane(woodBackground, newNode);
        dropdownContainer.setAlignment(Pos.CENTER); 
        dropdownContainer.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);

        // Add the new dropdown ON TOP of the existing overlay
        root.getChildren().add(dropdownContainer);
        
        // Force JavaFX to calculate the layout
        root.applyCss();
        root.layout();

        double targetHeight = dropdownContainer.getHeight();
        if (targetHeight <= 0) targetHeight = 300; // Safety fallback

        // Create the dropdown mask
        Rectangle clip = new Rectangle();
        clip.widthProperty().bind(dropdownContainer.widthProperty());
        clip.setHeight(0); 
        dropdownContainer.setClip(clip);

        // Animate the 12-frame wood
        double frameWidth = woodImg.getWidth() / 12.0;
        double frameHeight = woodImg.getHeight();
        
        Timeline woodTimeline = new Timeline();
        for (int i = 0; i < 12; i++) {
            final int frame = i;
            woodTimeline.getKeyFrames().add(new KeyFrame(Duration.millis(i * 40), e -> {
                woodBackground.setViewport(new Rectangle2D(frame * frameWidth, 0, frameWidth, frameHeight));
            }));
        }

        // Animate the mask (Drop down effect)
        Timeline clipTimeline = new Timeline(
            new KeyFrame(Duration.ZERO, new KeyValue(clip.heightProperty(), 0, Interpolator.EASE_IN)),
            new KeyFrame(Duration.millis(480), new KeyValue(clip.heightProperty(), targetHeight, Interpolator.EASE_OUT))
        );

        woodTimeline.play();
        clipTimeline.play();
    }
    
    /**
     * CLOSE POPUP — Rolls the wooden dropdown up and fades out the overlay.
     */
    public void closePopup() {
        // If we only have the parent screen, there's nothing to close
        if (root.getChildren().size() <= 1) return;

        // The dropdown container is the top-most node
        Node topNode = root.getChildren().get(root.getChildren().size() - 1);
        if (!(topNode instanceof StackPane)) return;

        StackPane dropdownContainer = (StackPane) topNode;
        
        // The clip is the mask we used to reveal it
        Rectangle clip = (Rectangle) dropdownContainer.getClip();
        
        // The dark overlay is the middle node (index 1)
        Node overlayNode = root.getChildren().size() > 2 ? root.getChildren().get(1) : null;

        // Safety fallback if clip is missing
        if (clip == null) {
            root.getChildren().remove(1, root.getChildren().size());
            return;
        }

        // 1. Animate the mask shrinking back up to 0
        Timeline clipTimeline = new Timeline(
            new KeyFrame(Duration.ZERO, new KeyValue(clip.heightProperty(), clip.getHeight())),
            new KeyFrame(Duration.millis(300), new KeyValue(clip.heightProperty(), 0, Interpolator.EASE_IN))
        );

        // 2. Animate the wood in reverse (Frame 11 back to 0)
        Timeline woodTimeline = null;
        Node graphicNode = dropdownContainer.getChildren().get(0); // Wood background is at index 0
        
        if (graphicNode instanceof ImageView) {
            ImageView woodBackground = (ImageView) graphicNode;
            Image woodImg = woodBackground.getImage();
            double frameWidth = woodImg.getWidth() / 12.0;
            double frameHeight = woodImg.getHeight();

            woodTimeline = new Timeline();
            for (int i = 0; i < 12; i++) {
                // 11 - i makes it go 11, 10, 9... down to 0
                final int frame = 11 - i; 
                woodTimeline.getKeyFrames().add(new KeyFrame(Duration.millis(i * 25), e -> {
                    woodBackground.setViewport(new Rectangle2D(frame * frameWidth, 0, frameWidth, frameHeight));
                }));
            }
        }

        // 3. Fade out the dark background overlay
        ParallelTransition transition = new ParallelTransition(clipTimeline);
        if (woodTimeline != null) transition.getChildren().add(woodTimeline);
        
        if (overlayNode != null) {
            FadeTransition fadeOverlay = new FadeTransition(Duration.millis(300), overlayNode);
            fadeOverlay.setToValue(0.0);
            transition.getChildren().add(fadeOverlay);
        }

        // 4. Clean up the screen ONLY after the animation finishes
        transition.setOnFinished(e -> {
            // Removes the overlay and the dropdown container, leaving the parent screen intact
            root.getChildren().remove(1, root.getChildren().size());
        });

        transition.play();
    }
    public void showMenu() {
        root.getChildren().setAll(menuContent);
    }

    public Button getLoginButton()    { return loginButton; }
    public Button getRegisterButton() { return registerButton; }
    public Button getExitButton()     { return exitButton; }
    public Stage  getStage()          { return stage; }
    public void   show()              { stage.show(); }
}