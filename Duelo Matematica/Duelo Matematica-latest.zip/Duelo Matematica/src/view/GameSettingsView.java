package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.*;

public class GameSettingsView {

    private final VBox root;
    private final Button backButton;
    private final Slider musicSlider;
    private final Slider sfxSlider;

    public GameSettingsView() {
        Label titleLabel = ViewUtils.createPopupHeaderLabel("SETTINGS");
        backButton = ViewUtils.createCloseButton("X");

        BorderPane headerBox = new BorderPane();
        headerBox.setCenter(titleLabel);
        headerBox.setRight(backButton);
        BorderPane.setAlignment(titleLabel, Pos.CENTER);

        musicSlider = new Slider(0, 100, 50);
        musicSlider.setPrefWidth(150);
        musicSlider.setMaxWidth(Double.MAX_VALUE);

        sfxSlider = new Slider(0, 100, 50);
        sfxSlider.setPrefWidth(150);
        sfxSlider.setMaxWidth(Double.MAX_VALUE);

        Label musicLabel = new Label("MUSIC");
        musicLabel.setFont(ViewUtils.getCustomFont(14));
        musicLabel.setStyle("-fx-text-fill: #333333;");
        
        Label sfxLabel = new Label("SFX");
        sfxLabel.setFont(ViewUtils.getCustomFont(14));
        sfxLabel.setStyle("-fx-text-fill: #333333;");

        GridPane formGrid = new GridPane();
        formGrid.setHgap(25);
        formGrid.setVgap(25);
        formGrid.setAlignment(Pos.CENTER);

        ColumnConstraints c1 = new ColumnConstraints();
        ColumnConstraints c2 = new ColumnConstraints();
        c2.setHgrow(Priority.ALWAYS);
        formGrid.getColumnConstraints().addAll(c1, c2);

        formGrid.add(musicLabel, 0, 0);
        formGrid.add(musicSlider, 1, 0);
        formGrid.add(sfxLabel, 0, 1);
        formGrid.add(sfxSlider, 1, 1);

        root = new VBox(30, headerBox, formGrid);
        root.setPadding(new Insets(15, 30, 30, 30));
        root.setAlignment(Pos.TOP_CENTER);
        root.setPrefWidth(400);
        root.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
        root.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");
    }

    public Node getRoot() { return root; }
    public Button getBackButton() { return backButton; }
    public Slider getMusicSlider() { return musicSlider; }
    public Slider getSfxSlider() { return sfxSlider; }
}